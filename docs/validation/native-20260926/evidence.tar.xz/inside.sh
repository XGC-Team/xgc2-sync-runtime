#!/usr/bin/env bash
set -euo pipefail
set +u
source /opt/ros/noetic/setup.bash
if [[ -f /review/.review/controller-ws/devel/setup.bash ]]; then source /review/.review/controller-ws/devel/setup.bash; fi
set -u
export PATH=/rust/bin:$PATH
export CARGO_HOME=/review/.review/cargo-home
export CARGO_NET_OFFLINE=true
export ROS_PREFIX=/opt/ros/noetic
export ROS_HOME=/review/.review/ros-home
export ROS_MASTER_URI=http://127.0.0.1:11419
export ROS_IP=127.0.0.1
export XGC2_WS=/review/.review/controller-ws
export PX4_CORE_LIB_DIR=$XGC2_WS/devel/lib
export REF_CORE_LIB_DIR=$PX4_CORE_LIB_DIR
export PX4_CONTROLLER_ROOT=$XGC2_WS/src/multirotor/px4_multirotor_controller
export REF_ROOT=$XGC2_WS/src/multirotor/multirotor_reference_trajectory
export XGC2_PREFIX=/usr
export ACADOS_ROOT=/opt/xgc2/acados
export LD_LIBRARY_PATH=$PX4_CORE_LIB_DIR:/opt/xgc2/acados/lib:/opt/ros/noetic/lib:${LD_LIBRARY_PATH:-}
exec "$@"
