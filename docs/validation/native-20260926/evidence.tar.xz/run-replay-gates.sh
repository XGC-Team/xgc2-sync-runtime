#!/usr/bin/env bash
set -euo pipefail
export REF_REPLAY_STREAM=/review/.review/reference-requests.stream
export REF_REPLAY_REF=/review/.review/reference-expected.txt
cargo test -p xgc-rt-host --test ref_trajectory_replay -- --nocapture --test-threads=1
for backend in px4_local dfbc nmpc; do
  export PX4_REPLAY_BACKEND="$backend"
  export PX4_REPLAY_REFERENCE_TYPE=3
  export PX4_REPLAY_STREAM="/review/.review/replays/$backend.stream"
  export PX4_REPLAY_REF="/review/.review/replays/$backend.expected.txt"
  cargo test -p xgc-rt-host --test ctl_px4_replay -- --nocapture --test-threads=1
done
