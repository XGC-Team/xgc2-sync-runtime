#!/usr/bin/env bash
set -euo pipefail
review_root="$(cd "$(dirname "$0")/.." && pwd)"
image="$(cat "$review_root/.review/runtime-image.txt")"
exec docker run --rm --network none --label com.docker.compose.project=pr-validation --label com.docker.compose.service=validation --entrypoint /bin/bash \
  -v /home/lxk/Dev/xgc2-harness/devops/products/ros1:/work/products/ros1:ro \
  -v /home/lxk/Dev/xgc2-harness/devops/products/common/math:/work/products/common/math:ro \
  -v /home/lxk/Dev/xgc2-harness/devops/products/common/state-machine:/work/products/common/state-machine:ro \
  -v "$review_root:/work/products/common/sync-runtime" \
  -v "$review_root:/review" \
  -v /home/lxk/Paper/academic:/academic:ro \
  -v /home/lxk/.rustup/toolchains/stable-x86_64-unknown-linux-gnu:/rust:ro \
  -w /work/products/common/sync-runtime "$image" /review/.review/inside.sh "$@"
