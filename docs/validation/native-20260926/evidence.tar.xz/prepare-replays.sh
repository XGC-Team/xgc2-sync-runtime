#!/usr/bin/env bash
set -euo pipefail
mkdir -p /review/.review/replays
for backend in px4_local dfbc nmpc; do
  python3 "$PX4_CONTROLLER_ROOT/test/replay/bag_to_stream.py" "/review/.review/bags/px4_flight_$backend.bag" "/review/.review/replays/$backend.stream"
  "$XGC2_WS/devel/lib/px4_multirotor_controller/px4_multirotor_controller_replay_harness" "/review/.review/replays/$backend.stream" "/review/.review/replays/$backend.expected.txt" "$backend" reference_analytic_type=3
  sha256sum "/review/.review/replays/$backend.stream" "/review/.review/replays/$backend.expected.txt"
done
